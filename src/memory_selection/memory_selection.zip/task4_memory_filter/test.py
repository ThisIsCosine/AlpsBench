from src.memory_selection.task4_memory_filter.filters_runner import RunnerConfig, run_filters

config = RunnerConfig(
    abilities=["ability1"],
    default_target=1,
    max_passes=1,
)
run_filters(config)